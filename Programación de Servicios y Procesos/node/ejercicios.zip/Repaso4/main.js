var lectura = require('./leerJSON')

lectura(function(datos1, datos2){
  console.log(datos1);
  console.log(datos2);
})
