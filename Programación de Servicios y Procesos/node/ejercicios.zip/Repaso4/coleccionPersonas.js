module.exports = function (arrayPersonas) {
  var _arrayPersonas = arrayPersonas;

  return {
    personaPorNombre : function () {

      var persona = _arrayPersonas[0];
      for (var i = 0; i < _arrayPersonas.length; i++) {
        if (_arrayPersonas[i].first_name === "Ekaterina") {
          persona = _arrayPersonas[i];
        }
      }
      return persona;
    },
    mayorDeId: function (id) {
      var _id = id;
      var coleccion = [];
      for (var i = 0; i < _arrayPersonas.length; i++) {
        if (_id < _arrayPersonas[i].id){
          coleccion.push(_arrayPersonas[i]);
        }
      }
      return coleccion;
    }
  }
}
