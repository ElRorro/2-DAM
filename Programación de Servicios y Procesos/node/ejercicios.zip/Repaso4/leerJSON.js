var fs = require('fs');
var coleccionPersonas = require('./coleccionPersonas')

module.exports = function lectura (callback) {
    var arrayPersonas = fs.readFileSync('datos.json');
    var arrayPersonas2 = JSON.parse(arrayPersonas);

    var coleccion = coleccionPersonas(arrayPersonas2);
    var personaPorNombre = coleccion.personaPorNombre();
    var personaMayorId = coleccion.mayorDeId(50);
    callback(personaPorNombre, personaMayorId);
}
