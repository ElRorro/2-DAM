module.exports = function (arrayPersonas) {
  var _arrayPersonas = arrayPersonas;

  return {
    personaMasEdad : function () {
      var edad = _arrayPersonas[0].edad;
      var personaMayorEdad = _arrayPersonas[0];

      for (var i = 0; i < _arrayPersonas.lenght; i++) {
        if (edad < _arrayPersonas[i].edad) {
          edad = _arrayPersonas[i].edad
          personaMayorEdad = _arrayPersonas[i];
        }
      }
      return personaMayorEdad;
    },
    personasSegunSexo: function (sexo) {
      var _sexo = sexo;
      var coleccionPersonasSexo = [];

      for (var i = 0; i < _arrayPersonas.length; i++) {
        if (_sexo === _arrayPersonas[i].sexo) {
          coleccionPersonasSexo.push(_arrayPersonas[i]);
        }
      }
      return coleccionPersonasSexo;
    }
  }

}
