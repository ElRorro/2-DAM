var fs = require('fs');
var coleccionPersona = require('./coleccionPersonas')

module.exports = function lectura ( callback) {
  var arrayPersonas = [];
  fs.readFile('datos.csv', 'utf-8', function(err, datos){
      if (err) throw err;
      var lineas = datos.split('\n');

      for (var i = 1; i < lineas.length - 1; i++) {
        var trozo = lineas[i].split(',');
        var persona = {};
        persona.nombre = trozo[0];
        persona.apellido = trozo[1];
        persona.email = trozo[2];
        persona.sexo = trozo[3];
        persona.edad = parseInt(trozo[4]);

        arrayPersonas.push(persona);
      }

      var personasArray = coleccionPersona(arrayPersonas);
      var personaMayorEdad = personasArray.personaMasEdad();
      var personasSegunSexo = personasArray.personasSegunSexo('M');

      callback(personaMayorEdad, personasSegunSexo);
  });

}
