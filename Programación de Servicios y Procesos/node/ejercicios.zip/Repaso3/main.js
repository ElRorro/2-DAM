var lectura = require('./leerCSV')

lectura(function(datos1, datos2){
  console.log(datos1);
  console.log(datos2);
})
